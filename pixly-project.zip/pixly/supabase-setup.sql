-- PIXLY DATABASE SETUP. Run the whole file in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text unique not null,
 full_name text default '', avatar_url text, bio text default '', created_at timestamptz default now()
);
create table if not exists public.posts (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
 caption text default '', media_url text not null, media_type text not null default 'image', file_name text,
 created_at timestamptz default now()
);
create table if not exists public.likes (
 post_id uuid references public.posts(id) on delete cascade, user_id uuid references public.profiles(id) on delete cascade,
 created_at timestamptz default now(), primary key(post_id,user_id)
);
create table if not exists public.comments (
 id uuid primary key default gen_random_uuid(), post_id uuid references public.posts(id) on delete cascade,
 user_id uuid references public.profiles(id) on delete cascade, body text not null, created_at timestamptz default now()
);
create table if not exists public.follows (
 follower_id uuid references public.profiles(id) on delete cascade, following_id uuid references public.profiles(id) on delete cascade,
 created_at timestamptz default now(), primary key(follower_id,following_id), check(follower_id<>following_id)
);
create table if not exists public.messages (
 id uuid primary key default gen_random_uuid(), sender_id uuid not null references public.profiles(id) on delete cascade,
 receiver_id uuid not null references public.profiles(id) on delete cascade, body text default '', file_url text, file_name text,
 created_at timestamptz default now(), check(sender_id<>receiver_id)
);
create table if not exists public.stories (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
 media_url text not null, media_type text default 'image', expires_at timestamptz not null default (now()+interval '24 hours'), created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.follows enable row level security;
alter table public.messages enable row level security;
alter table public.stories enable row level security;

drop policy if exists "Profiles are readable" on public.profiles;
create policy "Profiles are readable" on public.profiles for select to authenticated using (true);
drop policy if exists "Users create own profile" on public.profiles;
create policy "Users create own profile" on public.profiles for insert to authenticated with check (auth.uid()=id);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);

drop policy if exists "Posts readable by signed in users" on public.posts;
create policy "Posts readable by signed in users" on public.posts for select to authenticated using (true);
drop policy if exists "Users create own posts" on public.posts;
create policy "Users create own posts" on public.posts for insert to authenticated with check (auth.uid()=user_id);
drop policy if exists "Users delete own posts" on public.posts;
create policy "Users delete own posts" on public.posts for delete to authenticated using (auth.uid()=user_id);

drop policy if exists "Likes readable" on public.likes;
create policy "Likes readable" on public.likes for select to authenticated using (true);
drop policy if exists "Like as self" on public.likes;
create policy "Like as self" on public.likes for insert to authenticated with check (auth.uid()=user_id);
drop policy if exists "Unlike as self" on public.likes;
create policy "Unlike as self" on public.likes for delete to authenticated using (auth.uid()=user_id);

drop policy if exists "Comments readable" on public.comments;
create policy "Comments readable" on public.comments for select to authenticated using (true);
drop policy if exists "Comment as self" on public.comments;
create policy "Comment as self" on public.comments for insert to authenticated with check (auth.uid()=user_id);
drop policy if exists "Delete own comments" on public.comments;
create policy "Delete own comments" on public.comments for delete to authenticated using (auth.uid()=user_id);

drop policy if exists "Follows readable" on public.follows;
create policy "Follows readable" on public.follows for select to authenticated using (true);
drop policy if exists "Follow as self" on public.follows;
create policy "Follow as self" on public.follows for insert to authenticated with check (auth.uid()=follower_id);
drop policy if exists "Unfollow as self" on public.follows;
create policy "Unfollow as self" on public.follows for delete to authenticated using (auth.uid()=follower_id);

drop policy if exists "Users read own conversations" on public.messages;
create policy "Users read own conversations" on public.messages for select to authenticated using (auth.uid()=sender_id or auth.uid()=receiver_id);
drop policy if exists "Users send own messages" on public.messages;
create policy "Users send own messages" on public.messages for insert to authenticated with check (auth.uid()=sender_id);

drop policy if exists "Stories readable" on public.stories;
create policy "Stories readable" on public.stories for select to authenticated using (expires_at>now());
drop policy if exists "Users create own stories" on public.stories;
create policy "Users create own stories" on public.stories for insert to authenticated with check (auth.uid()=user_id);
drop policy if exists "Users delete own stories" on public.stories;
create policy "Users delete own stories" on public.stories for delete to authenticated using (auth.uid()=user_id);

-- Public media bucket. Use private buckets and signed URLs for confidential files in a production app.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('pixly-files','pixly-files',true,52428800,null)
on conflict (id) do update set public=true, file_size_limit=52428800, allowed_mime_types=null;
drop policy if exists "Authenticated users upload Pixly files" on storage.objects;
create policy "Authenticated users upload Pixly files" on storage.objects for insert to authenticated with check (bucket_id='pixly-files' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Pixly files are public" on storage.objects;
create policy "Pixly files are public" on storage.objects for select to public using (bucket_id='pixly-files');
drop policy if exists "Users delete own Pixly files" on storage.objects;
create policy "Users delete own Pixly files" on storage.objects for delete to authenticated using (bucket_id='pixly-files' and (storage.foldername(name))[1]=auth.uid()::text);

-- Enable realtime updates for new chat messages.
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null; when others then null; end $$;
