# Pixly — Social app starter

A mobile-first React + Vite social app connected to Supabase. Includes email/password auth, profiles, posts, image/video uploads, likes, comments, follows, 24-hour stories, direct text messaging and message file attachments.

## 1. Create Supabase backend
1. Open https://supabase.com and create a project.
2. Open **SQL Editor → New query**.
3. Open `supabase-setup.sql` from this project, copy the entire file, paste it into SQL Editor, and press **Run**.
4. Open **Project Settings → API** (or **Connect**) and copy the Project URL and anon/publishable key. Never use the `service_role` or secret key in a browser app.

## 2. Add environment variables
Create a file named `.env` in the project root (same level as `package.json`):

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_ANON_OR_PUBLISHABLE_KEY
```

Replace both values with your own Supabase project values. Do not share your keys publicly. The anon/publishable key is designed for browser use with RLS enabled; never put a service-role key here.

## 3. Run locally (optional)
Install Node.js, then run:

```bash
npm install
npm run dev
```

## 4. Deploy with Netlify
1. Push this project folder to a GitHub repository.
2. Open https://app.netlify.com and choose **Add new site → Import an existing project**.
3. Connect GitHub and select the Pixly repository.
4. Build command: `npm run build`; Publish directory: `dist`.
5. In **Site configuration → Environment variables**, add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` with the same values from Supabase.
6. Deploy, then trigger a new deploy after changing environment variables.

You can also open the folder in Bolt.new and ask it to run the Vite project. Add the same two environment variables in Bolt's environment/secrets settings before testing.

## Notes / production hardening
- This is a working starter/MVP, not a production Instagram clone. It does not yet include push notifications, video transcoding, moderation, reporting, password reset UI, profile editing UI, private account controls, or a full reels player.
- The current bucket is public so post/story media links can be displayed easily. Files shared in chat are also public URLs; do not upload sensitive/private documents. For private file sharing, switch to a private bucket and implement signed URLs plus stricter access policies.
- Supabase email confirmation settings may require users to verify email before logging in. Configure Auth → URL Configuration with your deployed site URL.
- File upload limit in the SQL is 50 MB. Adjust the bucket limit and app-side validation as needed.
- RLS policies protect database rows, but review and harden them before public launch.
